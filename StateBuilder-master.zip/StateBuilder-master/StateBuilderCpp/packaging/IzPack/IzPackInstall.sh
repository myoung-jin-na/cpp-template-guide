#!/bin/sh
java -jar StateBuilderCppLinuxSetup.jar
