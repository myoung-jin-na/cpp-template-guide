#!/bin/sh
$HOME/IzPack/bin/compile IzPackLinuxConf.xml -b ../../ -o StateBuilderCppLinuxSetup.jar -k standard
