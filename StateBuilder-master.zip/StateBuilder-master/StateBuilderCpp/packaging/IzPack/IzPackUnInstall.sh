#!/bin/sh
java -jar $HOME/StateBuilderCpp/Uninstaller/Uninstaller.jar
