#ifndef TESTOBSERVERINT_H
#define TESTOBSERVERINT_H

void testWithObserverInt();

#endif