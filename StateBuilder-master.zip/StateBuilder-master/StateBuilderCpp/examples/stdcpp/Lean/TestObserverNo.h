#ifndef TESTOBSERVERNO_H
#define TESTOBSERVERNO_H

void testWithObserverNo();

#endif