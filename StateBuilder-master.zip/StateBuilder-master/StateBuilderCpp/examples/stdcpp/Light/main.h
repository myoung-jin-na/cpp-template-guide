//
// C++ Interface: main
//
// Description: 
//
//
// Author: frederic heem <frederic.heem@gmail.com>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//



/** @class App is the entry point for the application.
 */
class App
{
  public:
    /** Default constructor
     */
    App();

    /** Default destructor
     */
    virtual ~App(){};
    
    /** App routine, 
     */
    int Main();

  protected:
    
};

