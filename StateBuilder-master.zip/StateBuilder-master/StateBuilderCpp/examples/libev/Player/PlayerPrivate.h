#ifndef LEDPRIVATE_H_
#define LEDPRIVATE_H_


class PlayerPrivate 
{
public:
    void DoOn();
    void DoOff();
};

#endif
