#include <iostream>
#include "Action.h"

using namespace std;

// Led implementation
Action::Action()
{
    
}

Action::~Action()
{
    
}


