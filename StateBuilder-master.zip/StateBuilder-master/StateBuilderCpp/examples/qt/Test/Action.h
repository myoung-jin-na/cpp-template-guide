#ifndef ACTION_H
#define ACTION_H

class Action
{
public:
    Action();

    virtual ~Action();
    
    
private:
};

#endif
