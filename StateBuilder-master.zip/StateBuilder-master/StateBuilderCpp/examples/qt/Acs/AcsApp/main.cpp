#include <QCoreApplication>
#include "Acs.h"
#include "AcsRequest.h"

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);



    return app.exec();
}
