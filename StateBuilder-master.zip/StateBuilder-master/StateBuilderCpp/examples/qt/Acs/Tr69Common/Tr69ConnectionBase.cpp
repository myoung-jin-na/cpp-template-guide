

#include "Tr69ConnectionBase.h"


/**
  @class Tr69ConnectionBase
*/
Tr69ConnectionBase::Tr69ConnectionBase(QObject *pParent) : QObject(pParent)
{
}

Tr69ConnectionBase::~Tr69ConnectionBase()
{
}
