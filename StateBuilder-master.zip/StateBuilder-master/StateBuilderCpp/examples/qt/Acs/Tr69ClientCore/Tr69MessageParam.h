#ifndef TR69MESSAGEPARAM_H
#define TR69MESSAGEPARAM_H

#include <QtCore/QString>
#include <QtCore/QList>


#endif
