#ifndef DOORPRIVATE_H
#define DOORPRIVATE_H

#include "Engine.h"
#include "DoorFsm.h"

class DoorPrivate {
public:
	Engine engine;
};

#endif /* #ifndef DOORPRIVATE_H */