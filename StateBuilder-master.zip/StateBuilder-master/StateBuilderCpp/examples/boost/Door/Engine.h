#pragma once

class Engine
{
public:
	Engine(void);
	~Engine(void);
	void StartOpen();
	void StartClose();
	void Stop();
};
