//------------------------------------------------------------------------------
// <copyright file="Fsm.hpp" company="StateForge">
//      Copyright (c) 2010-2012 StateForge.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

#ifndef FSM_HPP
#define FSM_HPP

#include <fsm/State.hpp>
#include <fsm/Context.hpp>

#endif
