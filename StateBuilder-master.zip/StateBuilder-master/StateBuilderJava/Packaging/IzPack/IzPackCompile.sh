#!/bin/sh
/Applications/IzPack/bin/compile IzPackLinuxConf.xml -b ../../ -o StateBuilderJava-LinuxSetup.jar -k standard

