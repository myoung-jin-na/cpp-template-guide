package com.stateforge.statemachine.examples.HelloWorld;

public class HelloWorldAction {

    public void doPrint(String message) {
        System.out.println(message);
    }

}
