package rounds.rscip.client;

public enum ActionType {
	JOIN,
	LEAVE
};
