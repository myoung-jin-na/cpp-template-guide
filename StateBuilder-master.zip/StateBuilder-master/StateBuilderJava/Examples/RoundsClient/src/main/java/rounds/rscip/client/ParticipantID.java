package rounds.rscip.client;

public class ParticipantID {
	private Long id;
	
	public ParticipantID(long l) {
		id = l;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
