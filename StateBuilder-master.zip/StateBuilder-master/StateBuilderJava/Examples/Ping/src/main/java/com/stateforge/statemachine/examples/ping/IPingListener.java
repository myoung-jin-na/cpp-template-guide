package com.stateforge.statemachine.examples.ping;

public interface IPingListener {
    void end();
}
