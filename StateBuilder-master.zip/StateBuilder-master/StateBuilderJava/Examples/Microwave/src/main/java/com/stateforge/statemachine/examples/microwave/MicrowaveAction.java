package com.stateforge.statemachine.examples.microwave;

public class MicrowaveAction {

	public void doPrint(String message) {
		System.out.println(message);
	}
}
