StateBuilderJava
============

*StateBuilderJava* is a state machine code generator that transforms a state machine description in XML into a java state pattern implementation.

The easiest way to integrate *StateBuilderJava* into the build system is to use the provided maven task. 


