var classsttcl_1_1internal_1_1_i_region_event_dispatch_without_args =
[
    [ "EventArgsSelectorType", "classsttcl_1_1internal_1_1_i_region_event_dispatch_without_args.html#af94701bda311aeb16b6a6b5db29819b1", null ],
    [ "InnerEventHandler", "classsttcl_1_1internal_1_1_i_region_event_dispatch_without_args.html#a2e1048a44a34ff56d321be4d69dcfa4d", null ],
    [ "RefCountPtr", "classsttcl_1_1internal_1_1_i_region_event_dispatch_without_args.html#a8f4ea6a94f9549f3df92409540af5af2", null ],
    [ "~IRegionEventDispatchWithoutArgs", "classsttcl_1_1internal_1_1_i_region_event_dispatch_without_args.html#a931a7227dc0be1c5e5bd9c38523277c1", null ],
    [ "handleBroadcastedEvent", "classsttcl_1_1internal_1_1_i_region_event_dispatch_without_args.html#a362fbc4ccc3f216153849afadcdb6663", null ]
];