var _sttcl_time_8h =
[
    [ "TimeDuration", "classsttcl_1_1_time_duration.html", "classsttcl_1_1_time_duration" ],
    [ "operator*", "_sttcl_time_8h.html#ac4ff2ba744e1d90e108963519d499c96", null ],
    [ "operator+", "_sttcl_time_8h.html#ae5353ab7569dd9c3a99e5d1a2542fbe8", null ],
    [ "operator-", "_sttcl_time_8h.html#a14a6d42cad45499bee226d50b2741668", null ],
    [ "operator/", "_sttcl_time_8h.html#a501bd953cd36b46694a7f65c804aa5a3", null ]
];