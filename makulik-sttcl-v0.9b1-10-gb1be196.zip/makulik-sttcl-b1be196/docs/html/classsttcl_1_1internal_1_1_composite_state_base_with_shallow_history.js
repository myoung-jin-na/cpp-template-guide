var classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history =
[
    [ "CompositeStateBaseWithShallowHistory", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#a9277215d965bab8567573344f616fba8", null ],
    [ "~CompositeStateBaseWithShallowHistory", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#a00b21c7063f0cc4aa5bd218ef73de89b", null ],
    [ "finalizeStateHistory", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#acb741bb11768640166b3da9b6916323d", null ],
    [ "getStateHistory", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#ae0a65dce1c67b2904ee1905982b62597", null ],
    [ "resumeStateHistory", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#a047ddf4a5fd40b43e94db147e8ef8f49", null ],
    [ "saveCurrentState", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#af2f4916122c53d9b6a6b3ee9f0e65240", null ],
    [ "lastState", "classsttcl_1_1internal_1_1_composite_state_base_with_shallow_history.html#aab4a1353641709f88528cd09bfa51b06", null ]
];