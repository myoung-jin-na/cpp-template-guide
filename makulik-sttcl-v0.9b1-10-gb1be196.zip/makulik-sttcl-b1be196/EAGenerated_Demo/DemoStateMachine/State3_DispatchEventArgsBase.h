///////////////////////////////////////////////////////////
//  State3_DispatchEventArgsBase.h
//  Implementation of the Class State3_DispatchEventArgsBase
//  Created on:      17-Jul-2012 22:48:11
//  Original author: Admin
///////////////////////////////////////////////////////////

#if !defined(EA_33AE782C_3EE9_4a78_B02F_E994D0B86D02__INCLUDED_)
#define EA_33AE782C_3EE9_4a78_B02F_E994D0B86D02__INCLUDED_

// Forward declarations from state diagram
struct State3_DispatchEventArgsBase
{

public:
	virtual ~State3_DispatchEventArgsBase();

protected:
	State3_DispatchEventArgsBase();

};
#endif // !defined(EA_33AE782C_3EE9_4a78_B02F_E994D0B86D02__INCLUDED_)
