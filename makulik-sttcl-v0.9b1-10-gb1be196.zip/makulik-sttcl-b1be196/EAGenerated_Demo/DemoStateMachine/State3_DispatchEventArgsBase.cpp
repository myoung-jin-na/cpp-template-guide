///////////////////////////////////////////////////////////
//  State3_DispatchEventArgsBase.cpp
//  Implementation of the Class State3_DispatchEventArgsBase
//  Created on:      17-Jul-2012 22:48:11
//  Original author: Admin
///////////////////////////////////////////////////////////

#include "State3_DispatchEventArgsBase.h"




State3_DispatchEventArgsBase::State3_DispatchEventArgsBase(){

}


State3_DispatchEventArgsBase::~State3_DispatchEventArgsBase(){

}